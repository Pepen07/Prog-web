<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Facturas</title>
    <link rel="stylesheet" href="estilos.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light">
    <a class="navbar-brand" href="#">LA RUBIA</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="Factura.php">Registrar Factura</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="registro_clientes.php">Registrar Cliente</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="registro_articulos.php">Registrar Artículo</a>
            </li>
            <li class="nav-item">
                <button type="button" class="btn btn-warning nav-link" onclick="runInstaller()">Ejecutar Instalador</button>
            </li>
        </ul>
    </div>
</nav>

<div class="container">
    <div class="card">
        <h1 class="text-center" style="color: #4b9cd3;">Registro de Facturas</h1>
        <form id="invoiceForm" action="registrar_factura.php" method="post">
            <div class="form-group">
                <label for="numeroComprobante">Número de Comprobante:</label>
                <input type="text" class="form-control" id="numeroComprobante" name="numeroComprobante" readonly>
            </div>
            <div class="form-group">
                <label for="fecha">Fecha:</label>
                <input type="date" class="form-control" id="fecha" name="fecha" required>
            </div>
            <div class="form-group">
                <label for="codigoCliente">Código del Cliente (Matrícula):</label>
                <input type="text" class="form-control" id="codigoCliente" name="codigoCliente" required onblur="checkCliente()">
            </div>
            <div class="form-group">
                <label for="nombreCliente">Nombre del Cliente:</label>
                <input type="text" class="form-control" id="nombreCliente" name="nombreCliente" required>
            </div>
            <div class="form-group">
                <label for="comentario">Comentario:</label>
                <textarea class="form-control" id="comentario" name="comentario" rows="4"></textarea>
            </div>
            <h2 style="color: #4b9cd3;">Artículos</h2>
            <table class="table table-bordered" id="itemsTable">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Cantidad</th>
                        <th>Precio</th>
                        <th>Total</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><input type="text" class="form-control" name="nombreArticulo[]" required></td>
                        <td><input type="number" class="form-control" name="cantidadArticulo[]" required></td>
                        <td><input type="number" class="form-control" name="precioArticulo[]" required></td>
                        <td><input type="number" class="form-control" name="totalArticulo[]" readonly></td>
                        <td><button type="button" class="btn btn-danger" onclick="removeItem(this)">Eliminar</button></td>
                    </tr>
                </tbody>
            </table>
            <div class="add-item" onclick="addItem()">Agregar Artículo</div>
            <div class="form-group">
                <label for="totalPagar">Total a Pagar:</label>
                <input type="number" class="form-control" id="totalPagar" name="totalPagar" readonly>
            </div>
            <button type="submit" class="btn btn-primary">Registrar Factura</button>
            <button type="button" class="btn btn-secondary" onclick="printInvoice()">Imprimir Factura</button>
        </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    let comprobanteCounter = 1;

    function checkCliente() {
        const codigoCliente = document.getElementById('codigoCliente').value;
        if (codigoCliente) {
            $.ajax({
                url: 'check_cliente.php',
                type: 'POST',
                data: { codigo_cliente: codigoCliente },
                success: function(response) {
                    const data = JSON.parse(response);
                    if (data.exists) {
                        document.getElementById('nombreCliente').value = data.nombre_cliente;
                    } else {
                        document.getElementById('nombreCliente').value = '';
                    }
                }
            });
        }
    }

    function addItem() {
        const table = document.getElementById('itemsTable').getElementsByTagName('tbody')[0];
        const newRow = table.insertRow();

        const nombreCell = newRow.insertCell(0);
        const cantidadCell = newRow.insertCell(1);
        const precioCell = newRow.insertCell(2);
        const totalCell = newRow.insertCell(3);
        const accionesCell = newRow.insertCell(4);

        nombreCell.innerHTML = '<input type="text" class="form-control" name="nombreArticulo[]" required>';
        cantidadCell.innerHTML = '<input type="number" class="form-control" name="cantidadArticulo[]" required>';
        precioCell.innerHTML = '<input type="number" class="form-control" name="precioArticulo[]" required>';
        totalCell.innerHTML = '<input type="number" class="form-control" name="totalArticulo[]" readonly>';
        accionesCell.innerHTML = '<button type="button" class="btn btn-danger" onclick="removeItem(this)">Eliminar</button>';

        addEventListeners();
    }

    function removeItem(button) {
        const row = button.parentNode.parentNode;
        row.parentNode.removeChild(row);
        calculateGrandTotal();
    }

    function addEventListeners() {
        const cantidadInputs = document.querySelectorAll('input[name="cantidadArticulo[]"]');
        const precioInputs = document.querySelectorAll('input[name="precioArticulo[]"]');

        cantidadInputs.forEach((input, index) => {
            input.addEventListener('input', () => calculateTotal(index));
        });

        precioInputs.forEach((input, index) => {
            input.addEventListener('input', () => calculateTotal(index));
        });
    }

    function calculateTotal(index) {
        const cantidadInputs = document.querySelectorAll('input[name="cantidadArticulo[]"]');
        const precioInputs = document.querySelectorAll('input[name="precioArticulo[]"]');
        const totalInputs = document.querySelectorAll('input[name="totalArticulo[]"]');

        const cantidad = parseFloat(cantidadInputs[index].value) || 0;
        const precio = parseFloat(precioInputs[index].value) || 0;
        const total = cantidad * precio;

        totalInputs[index].value = total.toFixed(2);

        calculateGrandTotal();
    }

    function calculateGrandTotal() {
        const totalInputs = document.querySelectorAll('input[name="totalArticulo[]"]');
        let grandTotal = 0;

        totalInputs.forEach(input => {
            grandTotal += parseFloat(input.value) || 0;
        });

        document.getElementById('totalPagar').value = grandTotal.toFixed(2);
    }

    document.getElementById('invoiceForm').addEventListener('submit', function(event) {
        event.preventDefault();
        $.ajax({
            url: 'guardar_factura.php',
            type: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                alert('Factura registrada con éxito');
                incrementComprobante();
            },
            error: function() {
                alert('Error al registrar la factura');
            }
        });
    });

    function incrementComprobante() {
        const comprobanteInput = document.getElementById('numeroComprobante');
        comprobanteInput.value = comprobanteCounter;
        comprobanteCounter++;
    }

    function printInvoice() {
        window.print();
    }

    addEventListeners();
    incrementComprobante();  // Inicializar el número de comprobante

    function runInstaller() {
        $.ajax({
            url: 'instalador.php',
            type: 'GET',
            success: function(response) {
                alert('Instalador ejecutado correctamente: ' + response);
            },
            error: function() {
                alert('Error al ejecutar el instalador');
            }
        });
    }
</script>

</body>
</html>
