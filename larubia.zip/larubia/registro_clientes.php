<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Clientes</title>
    <link rel="stylesheet" href="estilos.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light">
    <a class="navbar-brand" href="#">LA RUBIA</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="Factura.php">Registrar Factura</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="registro_clientes.php">Registrar Cliente</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="registro_articulos.php">Registrar Artículo</a>
            </li>
            <li class="nav-item">
                <button type="button" class="btn btn-warning nav-link" onclick="runInstaller()">Ejecutar Instalador</button>
            </li>
        </ul>
    </div>
</nav>

<div class="container">
    <div class="card">
        <h1 class="text-center" style="color: #4b9cd3;">Registro de Clientes</h1>
        <form id="clientForm">
            <div class="form-group">
                <label for="codigoCliente">Código del Cliente (Matrícula):</label>
                <input type="text" class="form-control" id="codigoCliente" name="codigoCliente" required>
            </div>
            <div class="form-group">
                <label for="nombreCliente">Nombre del Cliente:</label>
                <input type="text" class="form-control" id="nombreCliente" name="nombreCliente" required>
            </div>
            <button type="submit" class="btn btn-primary">Registrar Cliente</button>
        </form>
    </div>
</div>

<div class="container mt-5 custom-font">
        <div class="row justify-content-center">
            <div class="col-lg-10 col-md-12">
                <div class="centered-form-container">
                    <h4 class="text-center">LISTA DE ARTICULOS</h4>

                    <!-- Mostrar el mensaje de éxito o error -->
                    <?php if (isset($_SESSION['message'])): ?>
                        <div class="alert alert-success" role="alert">
                            <?php
                                echo $_SESSION['message'];
                                unset($_SESSION['message']); // Eliminar el mensaje después de mostrarlo
                            ?>
                        </div>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table class="table table-striped table-hover mt-4">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>codigo_cliente</th>
                                    <th>nombre_cliente</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php include 'get_clientes.php'; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="text-center mt-4">
                        <a href="Factura.php" class="btn btn-primary">
                            <i class="fas fa-arrow-left"></i> Volver al Inicio
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    document.getElementById('clientForm').addEventListener('submit', function(event) {
        event.preventDefault();
        const formData = new FormData(this);

        $.ajax({
            url: 'registrar_cliente.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                alert('Cliente registrado con éxito');
                document.getElementById('clientForm').reset();
            },
            error: function() {
                alert('Error al registrar el cliente');
            }
        });
    });
    function runInstaller() {
        $.ajax({
            url: 'instalador.php',
            type: 'GET',
            success: function(response) {
                alert('Instalador ejecutado correctamente: ' + response);
            },
            error: function() {
                alert('Error al ejecutar el instalador');
            }
        });
    }
</script>

</body>
</html>
