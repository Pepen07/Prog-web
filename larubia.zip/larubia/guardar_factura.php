<?php
include 'conexion.php';

// Obtener los datos del formulario
$numeroComprobante = $_POST['numeroComprobante'];
$fecha = $_POST['fecha'];
$codigoCliente = $_POST['codigoCliente'];
$nombreCliente = $_POST['nombreCliente'];
$comentario = $_POST['comentario'];
$totalPagar = $_POST['totalPagar'];

// Obtener los detalles de los artículos
$nombreArticulos = $_POST['nombreArticulo'];
$cantidadArticulos = $_POST['cantidadArticulo'];
$precioArticulos = $_POST['precioArticulo'];
$totalArticulos = $_POST['totalArticulo'];

// Concatenar los detalles de los artículos
$articulos = [];
for ($i = 0; $i < count($nombreArticulos); $i++) {
    $articulos[] = sprintf("Nombre: %s, Cantidad: %d, Precio: %.2f, Total: %.2f",
        $nombreArticulos[$i],
        $cantidadArticulos[$i],
        $precioArticulos[$i],
        $totalArticulos[$i]
    );
}
$articulosConcatenados = implode(" | ", $articulos);

// Insertar los datos en la tabla `factura`
$sql = "INSERT INTO factura (numero_comprobante, fecha, codigo_cliente, articulo, comentario, total_pagar)
        VALUES (?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssssd", $numeroComprobante, $fecha, $codigoCliente, $articulosConcatenados, $comentario, $totalPagar);

if ($stmt->execute()) {
    echo "Factura registrada con éxito";
} else {
    echo "Error al registrar la factura: " . $stmt->error;
}

// Cerrar la conexión
$stmt->close();
$conn->close();
?>
